package com.jdbctest.app;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Program {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		String driverName = "oracle.jdbc.driver.OracleDriver";
		String url = "jdbc:oracle:thin:@localhost:1521/xepdb1";
		String userId = "TESTUSER";
		String password = "12345";
		
		String sql = "SELECT * FROM NOTICE ORDER BY ID DESC";
		
		Class.forName(driverName);
		Connection conn = DriverManager.getConnection(url, userId, password);
		PreparedStatement stmt = conn.prepareStatement(sql);
		ResultSet rs = stmt.executeQuery();
		
		if (rs.next()) {
			do {
				System.out.printf("ID: %d, TITLE: %s, WRITER: %s, CONTENT: %s\n",
						rs.getInt("ID"), 
						rs.getString("TITLE"),
						rs.getString("WRITER_ID"), 
						rs.getString("CONTENT"));
			} while (rs.next());
		}
		
		rs.close();
		stmt.close();
		conn.close();
	}

}
