package com.jdbctest.app;

import java.sql.SQLException;
import java.util.List;

import com.jdbctest.app.entity.Notice;
import com.jdbctest.app.service.NoticeDAO;
import com.jdbctest.app.service.NoticeDAOImpl;
import com.jdbctest.app.service.NoticeDAOImplByDBCP;

public class Program2 {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		NoticeDAO dao = new NoticeDAOImplByDBCP();	//약한 결합을 위한 인터페이스 참조 가장 기본적인 지켜야할 규칙
		
		List<Notice> list = dao.getNoticeList();
		
		if(list != null) {
			for (Notice notice : list) {
				System.out.println(notice);
			}
		}
		else {
			System.out.println("동록된 게시글이 없습니다.");
		}
	}

}
