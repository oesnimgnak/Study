package com.jdbctest.app.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import com.jdbctest.app.entity.Notice;

public class NoticeDAOImpl implements NoticeDAO {

	//상수값들을 프로퍼티에 저장해서 사용
	/*
	 * private String driverClassName = "oracle.jdbc.driver.OracleDriver"; private
	 * String url = "jdbc:oracle:thin:@localhost:1521/xepdb1"; private String
	 * username = "NEWLEC"; private String password = "390829";
	 */
	private String driverClassName ;
	private String url ;
	private String username ;
	private String password ;
	
	
	private String LIST_NOTICE = "SELECT * FROM NOTICE ORDER BY ID DESC";
	private String GET_NOTICE = "SELECT * FROM NOTICE WHERE ID=?";
	private String INSERT_NOTICE = "INSERT INTO NOTICE(TITLE, WRITER_ID, CONTENT, FILES) VALUES (?, ?, ?, ?)";
	private String UPDATE_NOTICE = "UPDATE NOTICE SET TITLE=?, CONTENT=?, FILES=?, HIT=?, PUB=? WHERE ID=?";
	private String DELETE_NOTICE = "DELETE NOTICE WHERE ID=?";

	private Connection conn = null;
	private PreparedStatement stmt = null;
	private ResultSet rs = null;

	public NoticeDAOImpl() {	//패스 찾는 방법
		String path = System.getProperty("user.dir")+
				File.separator +"bin"+	//File.separator가 윈도우의 \와 리눅스, 유닉스의 /값을 가지고 있음
				File.separator +"dbconfig.properties";	//실제로는 bin 디렉토리 밑에 Input String을 얻어올 수 있다.
		
		Properties dbConfig = new Properties();
		try {
			dbConfig.load(new FileInputStream(path));
			driverClassName = dbConfig.getProperty("jdbc.driverClassName");
			url = dbConfig.getProperty("jdbc.url");
			username = dbConfig.getProperty("jdbc.username");
			password = dbConfig.getProperty("jdbc.password");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	protected Connection connectDB() throws ClassNotFoundException, SQLException {	//자식 클래스에서 사용하기 위해서 protected 
		Class.forName(driverClassName);	//class를 힙메모리에 로딩
		return DriverManager.getConnection(url, username, password);
	}
	
	private void disconnectDB() throws SQLException {	//닫아주기 위한
		if (rs != null) {
			rs.close();		//close하고
			rs = null;		//null로 만들어줌
		}
		if (stmt != null) {
			stmt.close();	//close하고
			stmt = null;	//null로 만들어줌
		}
		if (conn != null) {
			conn.close();	//close하고
			conn = null;	//null로 만들어줌, null값을 안줘도 상관없지만 버츄얼머신에 제거하기 위해 메모리를 최적화 하기 위한 동작, 딜리트 연산자를 대신한기 위한(딜리트 연산자 : 이 객체를 참조하는 변수가 하나도  없을 때)
		}
	}
	
	@Override
	public List<Notice> getNoticeList() {
		List<Notice> list = null;
		
		try {
			conn = connectDB();		
			stmt = conn.prepareStatement(LIST_NOTICE);	//Statement 객체 생성
			rs = stmt.executeQuery();	//쿼리 반환
			
			if (rs.next()) {	//--요부분을 //next() 시작점이 레코드 앞에 있다.
				list = new ArrayList<Notice>();	//객체 생성
				NoticeRowMapper rowMapper = new NoticeRowMapper();	//
				
				do {
					list.add(rowMapper.mapRow(rs));
				} while (rs.next());
			}//--이해해야함		
			
				/*do {
					Notice n = new Notice();	//DO 객체 생성
					n.setId(rs.getInt("ID"));	//DO 객체를 채움
					n.setTitle(rs.getString("TITLE"));
					n.setContent(rs.getString("CONTENT"));
					
					list.add(n);//리스트 생성 
				}	while (rs.next());
			}*/
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {	//반드시 실행
			try {
				disconnectDB();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return list;
	}

	@Override
	public Notice getNotice(Notice notice) {
		Notice result = null;
		
		try {
			conn = connectDB();
			stmt = conn.prepareStatement(GET_NOTICE);
			stmt.setInt(1, notice.getId());
			rs = stmt.executeQuery();
			
			if (rs.next()) {
				result =  (new NoticeRowMapper()).mapRow(rs);
			}			
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				disconnectDB();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return result;
	}

	@Override
	public int insertNotice(Notice notice) {
		int result = 0;
		
		try {
			conn = connectDB();
			stmt = conn.prepareStatement(INSERT_NOTICE);
			stmt.setString(1, notice.getTitle());
			stmt.setString(2, notice.getWriterId());
			stmt.setString(3, notice.getContent());
			stmt.setString(4, notice.getFiles());
			result = stmt.executeUpdate();		//반환값의 integer 수정되는 레코드의 갯수를 반환
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				disconnectDB();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return result;
	}

	@Override
	public int updateNotice(Notice notice) {
		int result = 0;
		
		try {
			conn = connectDB();
			stmt = conn.prepareStatement(UPDATE_NOTICE);
			stmt.setString(1, notice.getTitle());
			stmt.setString(2, notice.getContent());
			stmt.setString(3, notice.getFiles());
			stmt.setInt(4, notice.getHit());
			stmt.setInt(5, notice.getPub());
			stmt.setInt(6, notice.getId());
			result = stmt.executeUpdate();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				disconnectDB();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return result;
	}

	@Override
	public int deleteNotice(Notice notice) {
		int result = 0;
		
		try {
			conn = connectDB();
			stmt = conn.prepareStatement(DELETE_NOTICE);
			stmt.setInt(1, notice.getId());
			result = stmt.executeUpdate();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				disconnectDB();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return result;
	}

}
