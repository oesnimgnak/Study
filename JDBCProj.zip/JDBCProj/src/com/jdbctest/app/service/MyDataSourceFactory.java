package com.jdbctest.app.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Properties;

import javax.sql.DataSource;

import org.apache.commons.dbcp2.BasicDataSource;

import oracle.jdbc.pool.OracleDataSource;

public class MyDataSourceFactory {
	
	private static DataSource ds = null;
	
	private static String dataSourceType = null;
	
	private static String driverClassName;
	private static String url;
	private static String username;
	private static String password;
	
	private static Properties dbConfig;
	
	static {	// class Loading 할 때 실행됨
		String path = System.getProperty("user.dir") + File.separator + "bin" + File.separator + "dbconfig.properties";
		
		dbConfig = new Properties();
		try {
			dbConfig.load(new FileInputStream(path));
			driverClassName = dbConfig.getProperty("jdbc.driverClassName");
			url = dbConfig.getProperty("jdbc.url");
			username = dbConfig.getProperty("jdbc.username");
			password = dbConfig.getProperty("jdbc.password");
			dataSourceType = dbConfig.getProperty("jdbc.dataSourceType");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//원래는 properties에서 선언해 줘야함.
		setPropertyInitValue("initialSize", "0");
		setPropertyInitValue("maxWaitMillis", "0");
		setPropertyInitValue("maxTotal", "8");
		setPropertyInitValue("maxIdle", "8");
		setPropertyInitValue("minIdle", "0");

		setPropertyInitValue("validationQuery", "");
		setPropertyInitValue("validationQueryTimeoutSeconds", "-1");

		setPropertyInitValue("poolStatements", "False");
		setPropertyInitValue("maxOpenPreparedStatements", "-1");

		setPropertyInitValue("maxConnLifetimeMillis", "-1");

		setPropertyInitValue("testOnBorrow", "False");
		setPropertyInitValue("testOnReturn", "False");
		setPropertyInitValue("testOnCreate", "False");
		setPropertyInitValue("testWhileIdle", "False");
		setPropertyInitValue("evictionPolicyClassName", "org.apache.commons.pool2.impl.DefaultEvictionPolicy");
		setPropertyInitValue("timeBetweenEvictionRunsMillis", "-1");

		setPropertyInitValue("numTestsPerEvictionRun", "3");
		setPropertyInitValue("minEvictableIdleTimeMillis", "1800000");
		setPropertyInitValue("softMinEvictableIdleTimeMillis", "-1");

		setPropertyInitValue("removeAbandonedOnBorrow", "False");
		setPropertyInitValue("removeAbandonedTimeout", "300000");
		setPropertyInitValue("logAbandoned", "False");
	}
	
	private static void setPropertyInitValue(String propertyKey, String defaultValue) {
		String propertyValue = dbConfig.getProperty(propertyKey);
		if (propertyValue == null || propertyValue.trim().isEmpty()) {
			if (defaultValue == null || defaultValue.trim().isEmpty()) {
//				System.out.println("데이터베이스 프로퍼티에 " + propertyKey + "가 없어 기본값(공백)으로 설정합니다.");
				defaultValue = "";
			} else {
//				System.out.println("데이터베이스 프로퍼티에 " + propertyKey + "가 없어 기본값(" + defaultValue + ")으로 설정합니다.");
			}
			dbConfig.setProperty(propertyKey, defaultValue);
		}		
	}
	
	public static DataSource getDataSource() throws SQLException {
		if (ds == null) {
			if (dataSourceType.equalsIgnoreCase("oracle")) {
				OracleDataSource dataSource = new OracleDataSource();	// 이미 driverClassName을 알고 있기 때문에 따로 정의해 주지 않음
																		// static으로 선언하는 경우 객체 생성 과정 없이 클래스 로딩만으로도 실행가능.
																		// 아래를 호출하기 위해서. static은 static멤버 변수만 참조가능. 
														                // 객체를 초기화하는 과정은 생성자에서 이루어짐.
				
				dataSource.setURL(url);
				dataSource.setUser(username);
				dataSource.setPassword(password);
				
				ds = dataSource;
			} else if (dataSourceType.equalsIgnoreCase("dbcp2")) {
				BasicDataSource dataSource = new BasicDataSource();
				
				// 데이터베이스 드라이버
				dataSource.setDriverClassName(driverClassName);
				// 데이터베이스와 연결 URL
				dataSource.setUrl(url);
				// 데이터베이스와 연결 계정
				dataSource.setUsername(username);
				// 데이터베이스와 연결 패스워드
				dataSource.setPassword(password);
				
				String initialSizeInfo = dbConfig.getProperty("initialSize");
				int initialSize = Integer.parseInt(initialSizeInfo);
				String maxTotalInfo = dbConfig.getProperty("maxTotal");
				int maxTotal = Integer.parseInt(maxTotalInfo);
				String maxIdleInfo = dbConfig.getProperty("maxIdle");
				int maxIdle = Integer.parseInt(maxIdleInfo);
				String maxWaitMillisInfo = dbConfig.getProperty("maxWaitMillis");
				long maxWaitMillis = Long.parseLong(maxWaitMillisInfo);
				String minIdleConnection = dbConfig.getProperty("minIdle");
				int minIdle = Integer.parseInt(minIdleConnection);
	
				// 최초에 데이터베이스와 연결되는 커넥션 수
				dataSource.setInitialSize(initialSize);
				// 동시에 사용할 수 있는 최대 커넥션 개수
				dataSource.setMaxTotal(maxTotal);
				// 커넥션이 반환될 때 최대로 유지될 수 있는 커넥션 개수
				dataSource.setMaxIdle(maxIdle);
				// 커넥션을 가져오기 위해 대기하기 최대 시간
				dataSource.setMaxWaitMillis(maxWaitMillis);
				// 커넥션이 반환될 때 최소로 유지될 수 있는 커넥션 개수
				dataSource.setMinIdle(minIdle);
				
				String validationQuery = dbConfig.getProperty("validationQuery");
				String validationQueryTimeoutSecondsInfo = dbConfig.getProperty("validationQueryTimeoutSeconds");
				int validationQueryTimeoutSeconds = Integer.parseInt(validationQueryTimeoutSecondsInfo);
	
				// 커넥션이 유효한지 검사하기 위한 쿼리
				dataSource.setValidationQuery(validationQuery);
				// 커넥션이 유효한지 검사하는 쿼리가 실행되고 응답을 기다리는 시간
				dataSource.setValidationQueryTimeout(validationQueryTimeoutSeconds);
			
				String poolStatementsInfo = dbConfig.getProperty("poolStatements");
				boolean poolStatements = Boolean.parseBoolean(poolStatementsInfo);
				String maxOpenPreparedStatementsInfo = dbConfig.getProperty("maxOpenPreparedStatements");
				int maxOpenPreparedStatements = Integer.parseInt(maxOpenPreparedStatementsInfo);
	
				// 커넥션마다 PreparedStatement 풀링 여부
				dataSource.setPoolPreparedStatements(poolStatements);
				// 커넥션마다 최대로 풀링할 PreparedStatement의 개수
				dataSource.setMaxOpenPreparedStatements(maxOpenPreparedStatements);
				
				String maxConnLifetimeMillisInfo = dbConfig.getProperty("maxConnLifetimeMillis");
				long maxConnLifetimeMillis = Long.parseLong(maxConnLifetimeMillisInfo);
	
				// 커넥션의 생성후 최대로 이용 가능한 시간
				dataSource.setMaxConnLifetimeMillis(maxConnLifetimeMillis);	
				
				// 풀에서 사용되지 않는 커넥션들에 대한 유효성 검사
				String testOnBorrowInfo = dbConfig.getProperty("testOnBorrow");
				boolean testOnBorrow = Boolean.parseBoolean(testOnBorrowInfo);
				String testOnReturnInfo = dbConfig.getProperty("testOnReturn");
				boolean testOnReturn = Boolean.parseBoolean(testOnReturnInfo);
				String testOnCreateInfo = dbConfig.getProperty("testOnCreate");
				boolean testOnCreate = Boolean.parseBoolean(testOnCreateInfo);
				String testWhileIdleInfo = dbConfig.getProperty("testWhileIdle");
				boolean testWhileIdle = Boolean.parseBoolean(testWhileIdleInfo);
	
				// 풀에서 커넥션을 가져올 때 커넥션이 유효한지 검사 여부
				dataSource.setTestOnBorrow(testOnBorrow);
				// 풀에 커넥션을 반환할 때 커넥션이 유효한지 검사 여부
				dataSource.setTestOnReturn(testOnReturn);
				// 풀에서 커넥션을 생성한 후 커넥션이 유효한지 검사 여부
				dataSource.setTestOnCreate(testOnCreate);
				// 풀에서 사용되지 않는 커넥션들에 대해 유효한지 검사 여부 (유효하지 않으면 제거)
				dataSource.setTestWhileIdle(testWhileIdle);
				
				// 풀에서 사용되지 않는 커넥션들에 대한 추출(제거)
				String evictionPolicyClassName = dbConfig.getProperty("evictionPolicyClassName");
				String timeBetweenEvictionRunsMillisInfo = dbConfig.getProperty("timeBetweenEvictionRunsMillis");
				long timeBetweenEvictionRunsMillis = Long.parseLong(timeBetweenEvictionRunsMillisInfo);
				String numTestsPerEvictionRunInfo = dbConfig.getProperty("numTestsPerEvictionRun");
				int numTestsPerEvictionRun = Integer.parseInt(numTestsPerEvictionRunInfo);
				String minEvictableIdleTimeMillisInfo = dbConfig.getProperty("minEvictableIdleTimeMillis");
				long minEvictableIdleTimeMillis = Long.parseLong(minEvictableIdleTimeMillisInfo);
				String softMinEvictableIdleTimeMillisInfo = dbConfig.getProperty("softMinEvictableIdleTimeMillis");
				long softMinEvictableIdleTimeMillis = Long.parseLong(softMinEvictableIdleTimeMillisInfo);
	
				// 추출 정책 클래스 명 설정
				dataSource.setEvictionPolicyClassName(evictionPolicyClassName);
				// 풀에서 사용되지 않는 커넥션들에 대해 추출하는 Evictor 스레드의 검사 주기 (-1이면 검사하지 않음)
				dataSource.setTimeBetweenEvictionRunsMillis(timeBetweenEvictionRunsMillis);
				// Evictor 스레드의 검사 주기 때마다 풀에서 사용되지 않는 커넥션 중 검사할 커넥션 수
				dataSource.setNumTestsPerEvictionRun(numTestsPerEvictionRun);
				// 풀에서 사용되지 않는 커넥션이 최소로 유지될 수 있는 시간 (최소 유지 시간이 초과되면 제거)
				dataSource.setMinEvictableIdleTimeMillis(minEvictableIdleTimeMillis);
				// 풀에서 사용되지 않는 커넥션이 추출되기 전에 최소로 유지될 수 있는 시간
				dataSource.setSoftMinEvictableIdleTimeMillis(softMinEvictableIdleTimeMillis);
				
				// 풀에서 버려진 커넥션들에 대한 복구(재생)
				String removeAbandonedOnBorrowInfo = dbConfig.getProperty("removeAbandonedOnBorrow");
				boolean removeAbandonedOnBorrow = Boolean.parseBoolean(removeAbandonedOnBorrowInfo);
				String removeAbandonedTimeoutInfo = dbConfig.getProperty("removeAbandonedTimeout");
				int removeAbandonedTimeout = Integer.parseInt(removeAbandonedTimeoutInfo);
	
				// 풀에서 커넥션을 가져올 때 버려진 커넥션을 찾아 제거할지 여부
				dataSource.setRemoveAbandonedOnBorrow(removeAbandonedOnBorrow);
				// 풀에서 버려진 커넥션으로 인정할 수 있는 시간
				dataSource.setRemoveAbandonedTimeout(removeAbandonedTimeout);			
				
				String logAbandonedInfo = dbConfig.getProperty("logAbandoned");
				boolean logAbandoned = Boolean.parseBoolean(logAbandonedInfo);
	
				// 버려진 커넥션에 대한 로그 저장 여부
				dataSource.setLogAbandoned(logAbandoned);
				
				ds = dataSource;
			}
		}
		
		return ds;
	}
}
