package com.jdbctest.app.service;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.jdbctest.app.entity.Notice;

public class NoticeRowMapper {

	public Notice mapRow(ResultSet rs) throws SQLException {	//반환값은 DO 객체
		Notice notice = null;
		
		if (!rs.isClosed() && !rs.isAfterLast()) {	//클로즈 X, 리드 포인트가 마지막 다음에 있는 조건을 만족하면 아래를 수행
			notice = new Notice();
			notice.setId(rs.getInt("ID"));
			notice.setTitle(rs.getString("TITLE"));
			notice.setWriterId(rs.getString("WRITER_ID"));
			notice.setContent(rs.getString("CONTENT"));
			notice.setFiles(rs.getString("FILES"));
			notice.setRegDate(rs.getDate("REGDATE"));
			notice.setHit(rs.getInt("HIT"));
			notice.setPub(rs.getInt("PUB"));
		}
		
		return notice;
	}
	
}
