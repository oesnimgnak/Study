package com.jdbctest.app.service;

import java.util.List;

import com.jdbctest.app.entity.Notice;

public interface NoticeDAO {

	List<Notice> getNoticeList();
	Notice getNotice(Notice notice);
	int insertNotice(Notice notice);
	int updateNotice(Notice notice);
	int deleteNotice(Notice notice);
	
}
