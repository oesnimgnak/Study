package com.jdbctest.app.service;

import java.sql.Connection;
import java.sql.SQLException;

import javax.sql.DataSource;

public class NoticeDAOImplByDBCP extends NoticeDAOImpl {
	
	private DataSource dataSource = null;
	
	public NoticeDAOImplByDBCP() {
		try {
			dataSource = MyDataSourceFactory.getDataSource();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	protected Connection connectDB() throws ClassNotFoundException, SQLException {
		return dataSource.getConnection();
	}
	
}
