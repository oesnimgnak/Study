package com.jdbctest.app.service;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.jdbctest.app.entity.Notice;

public class NoticeRowMapper {

	public Notice mapRow(ResultSet rs) throws SQLException {
		Notice notice = null;
		
		if (!rs.isClosed() && !rs.isAfterLast()) {
			notice = new Notice();
			notice.setId(rs.getInt("ID"));
			notice.setTitle(rs.getString("TITLE"));
			notice.setWriterId(rs.getString("WRITER_ID"));
			notice.setContent(rs.getString("CONTENT"));
			notice.setFiles(rs.getString("FILES"));
			notice.setRegDate(rs.getDate("REGDATE"));
			notice.setHit(rs.getInt("HIT"));
			notice.setPub(rs.getInt("PUB"));
		}
		
		return notice;
	}
	
}
