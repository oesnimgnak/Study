package com.jdbctest.app;

import java.sql.SQLException;
import java.util.List;

import com.jdbctest.app.entity.Notice;
import com.jdbctest.app.service.NoticeDAO;
import com.jdbctest.app.service.NoticeDAOImpl;

public class Program2 {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		NoticeDAO dao = new NoticeDAOImpl();
		
		List<Notice> list = dao.getNoticeList();
		
		for (Notice notice : list) {
			System.out.println(notice);
		}
	}

}
