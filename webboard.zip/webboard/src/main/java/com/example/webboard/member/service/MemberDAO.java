package com.example.webboard.member.service;

import java.util.List;

import com.example.webboard.member.entity.Member;

public interface MemberDAO {
	
	List<Member> getMemberList();

	int insertMember(Member member);
	int updatetMember(Member member);
	int deleteMember(Member member);
}
