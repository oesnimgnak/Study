package com.example.webboard.notice.service;

import java.util.List;

import com.example.webboard.notice.entity.Notice;

public class NoticeServiceImpl implements NoticeService {
	//멤버변수 정의
	private NoticeDAO noticeDAO = new NoticeDAOImplByDBCP();

	@Override
	public List<Notice> getNoticeList() {	//첫페이지 요청
		return getNoticeList("TITLE", "", 1);
	}

	@Override
	public List<Notice> getNoticeList(int page) {
		return getNoticeList("TITLE", "", page);
	}

	@Override
	public List<Notice> getNoticeList(String field, String query, int page) {	//검색한 다음 페이지 요청
		return noticeDAO.getNoticeList(field, query, page);
	}

	@Override
	public int getNoticeCount() {
		return getNoticeCount("TITLE", "");
	}

	@Override
	public int getNoticeCount(String field, String query) {
		return noticeDAO.getNoticeCount(field, query);
	}

	@Override
	public Notice getNotice(int id) {
		Notice notice = new Notice();
		notice.setId(id);
		return noticeDAO.getNotice(notice);
	}

	@Override
	public Notice getNextNotice(int id) {	//다음글
		Notice notice = new Notice();
		notice.setId(id);
		return noticeDAO.getNextNotice(notice);
	}

	@Override
	public Notice getPrevNotice(int id) {	//이전글
		Notice notice = new Notice();
		notice.setId(id);
		return noticeDAO.getPrevNotice(notice);
	}

}
