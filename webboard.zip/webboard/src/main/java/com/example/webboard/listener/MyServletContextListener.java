package com.example.webboard.listener;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

import com.example.webboard.notice.service.MyDataSourceFactory;

/**
 * Application Lifecycle Listener implementation class MyServletContextListener
 *
 */
@WebListener
public class MyServletContextListener implements ServletContextListener {

    /**
     * Default constructor. 
     */
    public MyServletContextListener() {
        // TODO Auto-generated constructor stub
    }

	/**
     * @see ServletContextListener#contextInitialized(ServletContextEvent)
     */
    public void contextInitialized(ServletContextEvent sce)  {
    	ServletContext context = sce.getServletContext();
    	String dbConfigPath = context.getRealPath("/WEB-INF/classes/" + context.getInitParameter("db_config_props"));
    	context.setAttribute("db_config_path", dbConfigPath);
    	MyDataSourceFactory.init(dbConfigPath);
    }
	
}
