package com.example.webboard.member.service;

public interface MemberService {

}
