package com.example.webboard.notice.service;

import java.util.List;

import com.example.webboard.notice.entity.Notice;

public interface NoticeService {
	
	List<Notice> getNoticeList();
	List<Notice> getNoticeList(int page);
	List<Notice> getNoticeList(String field, String query, int page);
	int getNoticeCount();
	int getNoticeCount(String field, String query);
	Notice getNotice(int id);
	Notice getNextNotice(int id);
	Notice getPrevNotice(int id);

}
