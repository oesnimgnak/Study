package com.example.webboard.notice.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import com.example.webboard.notice.entity.Notice;

public class NoticeDAOImpl implements NoticeDAO {

//	private String driverClassName = "oracle.jdbc.driver.OracleDriver";
//	private String url = "jdbc:oracle:thin:@localhost:1521/xepdb1";
//	private String username = "TESTUSER";
//	private String password = "12345";
	
	private String driverClassName;
	private String url;
	private String username;
	private String password;

	private String LIST_NOTICE = "SELECT * FROM NOTICE_VIEW";
	private String LIST_NOTICE_PAGE = "SELECT * FROM NOTICE_VIEW WHERE NUM BETWEEN ? AND ?";
	private String LIST_NOTICE_SEARCH_F = 
		"SELECT * FROM " + 
			"(SELECT ROWNUM NUM, N.* FROM " + 
				"(SELECT * FROM NOTICE WHERE %s LIKE ? ORDER BY REGDATE DESC) N)" +
		" WHERE NUM BETWEEN ? AND ?";
	private String GET_NOTICE = "SELECT * FROM NOTICE WHERE ID=?";
//	private String GET_NOTICE_COUNT = "SELECT COUNT(ID) COUNT FROM NOTICE";
	private String GET_NOTICE_COUNT_F = "SELECT COUNT(ID) COUNT FROM NOTICE WHERE %s LIKE ?";
	private String INSERT_NOTICE = "INSERT INTO NOTICE(TITLE, WRITER_ID, CONTENT, FILES) VALUES (?, ?, ?, ?)";
	private String UPDATE_NOTICE = "UPDATE NOTICE SET TITLE=?, CONTENT=?, FILES=?, HIT=?, PUB=? WHERE ID=?";
	private String DELETE_NOTICE = "DELETE NOTICE WHERE ID=?";

	private Connection conn = null;
	private PreparedStatement stmt = null;
	private ResultSet rs = null;

	public NoticeDAOImpl() {
		// TODO Auto-generated constructor stub
	}
	
	public NoticeDAOImpl(String dbConfigPath) {
		init(dbConfigPath);
	}
	
	protected void init(String dbConfigPath) {
		Properties prop = new Properties();
		InputStream is = null;
		try {
			 is = new FileInputStream(dbConfigPath);
			 if (is != null) {
				prop.load(is);
				driverClassName = prop.getProperty("jdbc.driverClassName");
				url = prop.getProperty("jdbc.url");
				username = prop.getProperty("jdbc.username");
				password = prop.getProperty("jdbc.password");
			 }
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if (is != null) is.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	protected Connection connectDB() throws ClassNotFoundException, SQLException {
		Class.forName(driverClassName);
		return DriverManager.getConnection(url, username, password);
	}
	
	protected void disconnectDB() throws SQLException {
		if (rs != null) {
			rs.close();
			rs = null;
		}
		if (stmt != null) {
			stmt.close();
			stmt = null;
		}
		if (conn != null) {
			conn.close();
			conn = null;
		}
	}
	
	@Override
	public List<Notice> getNoticeList() {
		return getNoticeList(1);		
/*
		List<Notice> list = null;
		
		try {
			conn = connectDB();		
			stmt = conn.prepareStatement(LIST_NOTICE);
			rs = stmt.executeQuery();
			
			if (rs.next()) {
				list = new ArrayList<Notice>();
				NoticeRowMapper rowMapper = new NoticeRowMapper();
				
				do {
					list.add(rowMapper.mapRow(rs));
				} while (rs.next());
			}			
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				disconnectDB();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return list;
*/
	}

	@Override
	public List<Notice> getNoticeList(int page) {
		return getNoticeList("TITLE", "", page);
/*
		List<Notice> list = null;
		int start = (page - 1)*10 + 1;
		int end = page * 10;
		
		try {
			conn = connectDB();		
			stmt = conn.prepareStatement(LIST_NOTICE_PAGE);
			stmt.setInt(1, start);
			stmt.setInt(2, end);
			rs = stmt.executeQuery();
			
			if (rs.next()) {
				list = new ArrayList<Notice>();
				NoticeRowMapper rowMapper = new NoticeRowMapper();
				
				do {
					list.add(rowMapper.mapRow(rs));
				} while (rs.next());
			}			
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				disconnectDB();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return list;
*/
	}

	@Override
	public List<Notice> getNoticeList(String field, String keyword, int page) {
		List<Notice> list = null;
		int start = (page - 1)*10 + 1;
		int end = page * 10;
		
		try {
			conn = connectDB();		
			stmt = conn.prepareStatement(String.format(LIST_NOTICE_SEARCH_F, field));
			stmt.setString(1, "%"+keyword+"%");
			stmt.setInt(2, start);
			stmt.setInt(3, end);
			rs = stmt.executeQuery();
			
			if (rs.next()) {
				list = new ArrayList<Notice>();
				NoticeRowMapper rowMapper = new NoticeRowMapper();
				
				do {
					list.add(rowMapper.mapRow(rs));
				} while (rs.next());
			}			
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				disconnectDB();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return list;
	}

	@Override
	public Notice getNotice(Notice notice) {
		Notice result = null;
		
		try {
			conn = connectDB();
			stmt = conn.prepareStatement(GET_NOTICE);
			stmt.setInt(1, notice.getId());
			rs = stmt.executeQuery();
			
			if (rs.next()) {
				result =  (new NoticeRowMapper()).mapRow(rs);
			}			
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				disconnectDB();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return result;
	}

	@Override
	public int insertNotice(Notice notice) {
		int result = 0;
		
		try {
			conn = connectDB();
			stmt = conn.prepareStatement(INSERT_NOTICE);
			stmt.setString(1, notice.getTitle());
			stmt.setString(2, notice.getWriterId());
			stmt.setString(3, notice.getContent());
			stmt.setString(4, notice.getFiles());
			result = stmt.executeUpdate();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				disconnectDB();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return result;
	}

	@Override
	public int updateNotice(Notice notice) {
		int result = 0;
		
		try {
			conn = connectDB();
			stmt = conn.prepareStatement(UPDATE_NOTICE);
			stmt.setString(1, notice.getTitle());
			stmt.setString(2, notice.getContent());
			stmt.setString(3, notice.getFiles());
			stmt.setInt(4, notice.getHit());
			stmt.setInt(5, notice.getPub());
			stmt.setInt(6, notice.getId());
			result = stmt.executeUpdate();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				disconnectDB();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return result;
	}

	@Override
	public int deleteNotice(Notice notice) {
		int result = 0;
		
		try {
			conn = connectDB();
			stmt = conn.prepareStatement(DELETE_NOTICE);
			stmt.setInt(1, notice.getId());
			result = stmt.executeUpdate();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				disconnectDB();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return result;
	}

	@Override
	public int getNoticeCount() {
		return getNoticeCount("TITLE", "");
/*		
		int result = 0;
		
		try {
			conn = connectDB();
			stmt = conn.prepareStatement(GET_NOTICE_COUNT);
			rs = stmt.executeQuery();
			
			if (rs.next()) {
				result =  rs.getInt("COUNT");
			}			
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				disconnectDB();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return result;
*/
	}

	@Override
	public int getNoticeCount(String field, String keyword) {
		int result = 0;
		
		try {
			conn = connectDB();
			stmt = conn.prepareStatement(String.format(GET_NOTICE_COUNT_F, field));
			stmt.setString(1, "%"+keyword+"%");
			rs = stmt.executeQuery();
			
			if (rs.next()) {
				result =  rs.getInt("COUNT");
			}			
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				disconnectDB();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return result;
	}

	@Override
	public Notice getNextNotice(Notice notice) {		//구현해 오기
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Notice getPrevNotice(Notice notice) {
		// TODO Auto-generated method stub
		return null;
	}

}
