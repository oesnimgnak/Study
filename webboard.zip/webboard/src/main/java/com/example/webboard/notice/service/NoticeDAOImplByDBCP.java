package com.example.webboard.notice.service;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public class NoticeDAOImplByDBCP extends NoticeDAOImpl {
	
	private DataSource ds = null;

	public NoticeDAOImplByDBCP() {
		init(null);
	}	

	@Override
	protected void init(String dbConfigPath) {
		try {
			ds = MyDataSourceFactory.getDataSource();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	protected Connection connectDB() throws ClassNotFoundException, SQLException {
		if (ds != null) {
			return ds.getConnection();
		}
		return null;
	}

}
