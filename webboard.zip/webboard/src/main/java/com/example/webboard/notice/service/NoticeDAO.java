package com.example.webboard.notice.service;

import java.util.List;

import com.example.webboard.notice.entity.Notice;

public interface NoticeDAO {

	List<Notice> getNoticeList();
	List<Notice> getNoticeList(int page);
	List<Notice> getNoticeList(String field, String keyword, int page);
	int getNoticeCount();
	int getNoticeCount(String field, String keyword);
	Notice getNotice(Notice notice);
	int insertNotice(Notice notice);
	int updateNotice(Notice notice);
	int deleteNotice(Notice notice);
	Notice getNextNotice(Notice notice);
	Notice getPrevNotice(Notice notice);
	
}
